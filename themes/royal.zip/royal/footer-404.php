<?php global $royalConfig; ?>
<?php RoyalTheme::inlineScripts( get_the_ID( ) ); ?>
<?php wp_footer( ); ?>
</body>
</html>