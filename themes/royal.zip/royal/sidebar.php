<div class="row">
	<div class="col-md-12 col-sm-12">
		<?php dynamic_sidebar( 'sidebar-primary' ); ?>
	</div>
</div>